#include "../suppliers/beans.h"
#include "roaster.h"

// Make your own roaster ADT
