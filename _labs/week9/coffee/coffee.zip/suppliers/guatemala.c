#include "beans.h"

// Make your own ADT!
